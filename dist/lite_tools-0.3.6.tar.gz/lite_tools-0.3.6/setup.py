# -*- coding: utf-8 -*-
# @Time   : 2021-04-06 15:25
# @Author : Lodge
from setuptools import setup


setup(
    name='lite_tools',
    version='0.3.6',
    description='try_get修复try_get_by_name的bug',
    author='Lodge',
    author_email='lodgeheartfilia@163.com',
    url='https://gitee.com/lodgeheartfilia',
    packages=['lite_tools'],
    install_requires=['loguru', 'user_agent'],
)
