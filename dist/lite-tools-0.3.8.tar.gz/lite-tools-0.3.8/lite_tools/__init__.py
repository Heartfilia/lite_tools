# -*- coding: utf-8 -*-
# @Time   : 2021-04-06 15:50
# @Author : Lodge
from .time_info import get_time
from .ua_info import get_ua, get_navigator
from .try_get import try_get, try_get_by_name
