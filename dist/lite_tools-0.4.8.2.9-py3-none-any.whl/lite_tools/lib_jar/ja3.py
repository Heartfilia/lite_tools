# -*- coding: utf-8 -*-
# @Author  : Lodge
"""
      ┏┛ ┻━━━━━┛ ┻┓
      ┃　　　　　　 ┃
      ┃　　　━　　　┃
      ┃　┳┛　  ┗┳　┃
      ┃　　　　　　 ┃
      ┃　　　┻　　　┃
      ┃　　　　　　 ┃
      ┗━┓　　　┏━━━┛
        ┃　　　┃   神兽保佑
        ┃　　　┃   代码无BUG！
        ┃　　　┗━━━━━━━━━┓
        ┃　　　　　　　    ┣┓
        ┃　　　　         ┏┛
        ┗━┓ ┓ ┏━━━┳ ┓ ┏━┛
          ┃ ┫ ┫   ┃ ┫ ┫
          ┗━┻━┛   ┗━┻━┛
"""
import sys
from loguru import logger

try:
    from lite_tools.utils_jar.RequestsAdapter import ssl_gen as sync_ja3
    from lite_tools.utils_jar.AiohttpAdapter import ssl_gen as async_ja3
except ImportError:
    logger.warning("因为要requests模块,所以需要安装补充版: lite-tools[all] 或者自己装 `requests` 就好了")
    sys.exit(0)
